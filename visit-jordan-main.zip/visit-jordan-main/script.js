let list = document.getElementById("list");
let check = document.getElementById("check")
list.onclick= function(){
    check.checked = false;
}