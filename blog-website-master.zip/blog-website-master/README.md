# blog-website


this project was a challange to practice ejs with nodejs and expressjs, but without a database.

also i used body-parser and lodash.

this website is not published , you can clone the code and run it in your pc. 
