# dice-game
for study

I created this simple app while studying how to manipulate html using javascript or the dom manipulation.

published at https://abdallahds.github.io/dice-game/.
