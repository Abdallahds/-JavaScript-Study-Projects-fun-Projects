# The-Simon-Game

this game was developed with a udemy course , as a challenged after learning jquery. 

published at https://abdallahds.github.io/The-Simon-Game/
